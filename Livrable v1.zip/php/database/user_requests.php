<?php
$serverRoot = $_SERVER["DOCUMENT_ROOT"] . "/..";
require_once("$serverRoot/php/classes/User.php");

function dbAddUser($db, $user) {
  try{
      $request = 'INSERT INTO User(email, password, name, first_name, phone, city, zip_code, street, birth_date, country_code)
                  VALUES(:email, :password, :name, :first_name, :phone, :city, :zip_code, :street, :birth_date, :country_code)';

      $statement = $db->prepare($request);
      $statement->bindValue(":email", $user->getEmail());
      $statement->bindValue(":password", hash("sha256", $user->getPassword()));
      $statement->bindValue(":name", $user->getName());
      $statement->bindValue(":first_name", $user->getFirstName());
      $statement->bindValue(":phone", $user->getPhone());
      $statement->bindValue(":city", $user->getCity());
      $statement->bindValue(":zip_code", $user->getZipCode());
      $statement->bindValue(":street", $user->getStreet());
      $statement->bindValue(":birth_date", $user->getBirthDate());
      $statement->bindValue(":country_code", $user->getCountry());

      return $statement->execute();
  }
  catch (PDOException $exception){
      error_log('Request error: ' . $exception->getMessage());
      return false;
  }
}

//Fonction pour récupérer un utilisateur en fonction de son email et de son mdp
function dbStartUserSession($db, $email, $password) {
    $result = false;

    try{
        $newToken = uniqid("", true);

        $request = 'UPDATE User SET token=:token
                    WHERE email=:email AND password=:password';
        $statement = $db->prepare($request);
        $statement->bindValue(":token", $newToken);
        $statement->bindValue(":email", $email);
        $statement->bindValue(":password", hash("sha256", $password));

        $statement->execute();

        return dbGetUser($db, $newToken);
    }
    catch (PDOException $exception){
        error_log('Request error: ' . $exception->getMessage());
        return false;
    }

    return $result;
}

function dbGetUser($db, $userToken) {
  $result = false;

  try {
    $request = 'SELECT email, u.name AS name, first_name, phone, city, zip_code, DATE_FORMAT(birth_date, "%d/%m/%Y") AS birth_date, street, token, c.name AS country
                FROM User u, Country c
                WHERE u.token=:token AND c.iso_code = u.country_code';

    $statement = $db->prepare($request);
    $statement->bindParam(":token", $userToken);
    $statement->execute();

    if($statement->rowCount() == 1)
      $result = $statement->fetchObject("User");
  }
  catch (PDOException $exception){
      error_log('Request error: ' . $exception->getMessage());
      return false;
  }

  return $result;
}

function dbCheckToken($db, $token) {
  try {
    $request = 'SELECT email
                FROM User
                WHERE token=:token';

    $statement = $db->prepare($request);
    $statement->bindParam(":token", $token);
    $statement->execute();

    if($statement->rowCount() == 1)
      return true;
  }
  catch (PDOException $exception){
      error_log('Request error: ' . $exception->getMessage());
      return false;
  }

  return false;
}
