<?php
  define('DB_USER', 'Ryoko');
  define('DB_PASSWORD','#grp11@Ryoko!');
  define('DB_NAME','Ryoko');
  define('DB_SERVER','127.0.0.1');
?>
